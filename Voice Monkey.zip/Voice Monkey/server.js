const express = require('express');
const { exec } = require('child_process');
const path = require('path');
const app = express();
const PORT = 3000;

// Root Route - Optional (for clarity when accessing localhost directly)
app.get('/', (req, res) => {
    res.send('Server is running. Use /run-script to execute the script.');
});

// Route to Trigger the Script
app.get('/run-script', (req, res) => {
    const scriptPath = path.join('C:\\Users\\peppe\\OneDrive\\Desktop\\Voice Monkey');
    exec('cmd /c code_workshop.bat', { cwd: scriptPath }, (error, stdout, stderr) => {
        if (error) {
            console.error(`❌ Error: ${error.message}`);
            console.error(`Stderr: ${stderr}`);
            return res.status(500).send('Failed to run code_workshop.bat');
        }
        console.log(`✅ Output: ${stdout}`);
        res.send('Script executed successfully!');
    });
});

// Catch-All Route for Undefined Paths
app.get('*', (req, res) => {
    res.status(404).send('404 Not Found');
});

// Start the Server
app.listen(PORT, () => {
    console.log(`✅ Server running on http://localhost:${PORT}`);
});
