Steps to startup

1. Run node server.js to start local server
2. Run ngrok http 3000
3. Paste the link into voice monkey flow
4. Should be good to go, need to figure out how to automate this

Steps to adding a new command

1. Create new script
2. Add a new route to server.js
Example:
app.get('/run-new-script', (req, res) => {
    exec('cmd /c new_script.bat', (error, stdout, stderr) => {
        if (error) {
            console.error(`Error: ${error.message}`);
            return res.status(500).send('Failed to run new script');
        }
        console.log(`Output: ${stdout}`);
        res.send('New script executed successfully!');
    });
});

5. Update ngrok http 3000

6. Create new monkey flow using the link
7. Add a new alexa routine

FOR HELP VISIT:
https://voicemonkey.io/docs

Domain( I made this consistant in ngrok dashboard so it should remain the same ) this is what you put into the console to start ngrok, from there you would put the url it gives in code monkey, but it should stay the same now.
ngrok http --url=inviting-hen-overly.ngrok-free.app 3000

If you want to alter when the action in the computer takes place go to task scheduler and do at startup
This would be good for turning the computer off and on. The current workshop does not need it.
